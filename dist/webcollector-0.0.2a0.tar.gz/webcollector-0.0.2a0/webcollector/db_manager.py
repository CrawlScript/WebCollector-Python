# coding=utf-8


class DBManager(object):

    def inject(self, seeds):
        pass

    def write_crawl(self, crawl_datum):
        pass

    def init_fetch_and_detect(self):
        pass

    def write_fetch(self, crawl_datum):
        pass

    def write_detect(self, crawl_datum):
        pass

    def merge(self):
        pass

    def create_generator(self):
        return None
