# coding=utf-8


class Requester(object):

    async def get_response(self, crawl_datum):
        return None

    def create_async_context_manager(self):
        return None